<?php
$host = 'localhost';
$username = 'cynosure';
$password = 'CynoSure1!';
$database = 'cynosure';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Login logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username']; // Change 'email' to 'username'
    $password = $_POST['password'];

    // Retrieve user data from the database based on the provided username
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $hashedPassword = $row['password'];

            // Verify the entered password against the hashed password
            if (password_verify($password, $hashedPassword)) {
                // Set the session and redirect on successful login
                session_start();
                $_SESSION['username'] = $row['username'];
                header("Location: ../auth/home.php");
                exit();
            } else {
                header("Location: ../pages/login.html");
            }
        } else {
            header("Location: ../pages/login.html");
        }
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
