<?php
$host = 'localhost';
$username = 'cynosure';
$password = 'CynoSure1!';
$database = 'cynosure';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Registration logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if the username is unique
    $checkUsernameQuery = "SELECT * FROM users WHERE username = '$username'";
    $checkUsernameResult = $conn->query($checkUsernameQuery);

    if ($checkUsernameResult->num_rows > 0) {
        // Username is not unique, show an error message or redirect back to registration page
        echo "Username is already taken. Please choose a different one.";
        exit();
    }

    // If the username is unique, proceed with the registration
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $insertQuery = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hashedPassword')";

    if ($conn->query($insertQuery) === TRUE) {
        session_start();
        $_SESSION['username'] = $_POST['username'];
        // Redirect to a success page or login page
        header("Location: ../auth/home.php");
        exit();
    } else {
        echo "Error: " . $insertQuery . "<br>" . $conn->error;
    }
}

$conn->close();
